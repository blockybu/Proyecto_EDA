package model;
import java.util.Date;
public class Expediente {
    private int identificador;
    private String prioridad;
    private String datosInteresado;
    private String asunto;
    private String docReferencia;
    private Date fechaInicio;
    private Date fechaFin;

    public Expediente(int identificador, String prioridad, String datosInteresado,
                      String asunto, String docReferencia) {
        this.identificador = identificador;
        this.prioridad = prioridad;
        this.datosInteresado = datosInteresado;
        this.asunto = asunto;
        this.docReferencia = docReferencia;
        this.fechaInicio = new Date(); // Se establece la fecha de inicio al crear el expediente
        this.fechaFin = null; // La fecha de fin se establecerá cuando se finalice el trámite
    }

    // Métodos getters y setters para acceder a los atributos

    public int getIdentificador() {
        return identificador;
    }

    public void setIdentificador(int identificador) {
        this.identificador = identificador;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public String getDatosInteresado() {
        return datosInteresado;
    }

    public void setDatosInteresado(String datosInteresado) {
        this.datosInteresado = datosInteresado;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getDocReferencia() {
        return docReferencia;
    }

    public void setDocReferencia(String docReferencia) {
        this.docReferencia = docReferencia;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }
}
