package controller;
import java.util.HashMap;
import java.util.Map;
public class AuthController {
    private Map<String, String> usuarios;
    
    public AuthController() {
        // En un escenario real, los datos del usuario se almacenarían de manera segura,
        // como en una base de datos con contraseñas cifradas.
        usuarios = new HashMap<>();
        usuarios.put("usuario1", "password1");
        usuarios.put("usuario2", "password2");
        // Agrega más usuarios según sea necesario
    }

    public boolean autenticar(String username, String password) {
        // Verifica si el usuario existe y la contraseña coincide
        return usuarios.containsKey(username) && usuarios.get(username).equals(password);
    }
}
