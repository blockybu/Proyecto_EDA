package controller;
import java.util.List;
import java.util.ArrayList;
public class AdminCuentasController {
    
    private List<Usuario> usuarios;

    public AdminCuentasController() {
        this.usuarios = new ArrayList<>();
    }
    
    public void crearCuenta(String usuario, String contraseña) {
        Usuario nuevaCuenta = new Usuario(usuario, contraseña);
        usuarios.add(nuevaCuenta);
        System.out.println("Cuenta creada para el usuario: " + usuario);
    }

    public void eliminarCuenta(String usuario) {
        usuarios.removeIf(u -> u.getNombreUsuario().equals(usuario));
        System.out.println("Cuenta eliminada para el usuario: " + usuario);
    }

    public void cambiarContraseña(String usuario, String nuevaContraseña) {
        // Buscar la cuenta de usuario por el nombre de usuario
        for (Usuario u : usuarios) {
            if (u.getNombreUsuario().equals(usuario)) {
                // Cambiar la contraseña
                u.setContraseña(nuevaContraseña);
                System.out.println("Contraseña cambiada para el usuario: " + usuario);
                return; // Salir del bucle una vez que se encuentra la cuenta
            }
        }
        // Si no se encuentra la cuenta
        System.out.println("No se encontró la cuenta para cambiar la contraseña: " + usuario);
    }

}
