package controller;
import java.util.ArrayList;
import java.util.List;
public class AdminDependenciasController {
    private List<String> dependencias;

    public AdminDependenciasController() {
        // Inicializar la lista de dependencias
        dependencias = new ArrayList<>();
    }

    public List<String> obtenerDependencias() {
        // Devuelve la lista actual de dependencias
        return dependencias;
    }

    public void agregarDependencia(String nuevaDependencia) {
        // Lógica para agregar una nueva dependencia
        dependencias.add(nuevaDependencia);
    }

    public void eliminarDependencia(String dependencia) {
        // Lógica para eliminar una dependencia
        dependencias.remove(dependencia);
    }
    
    public void limpiarDependencias() {
        // Lógica para borrar todas las dependencias
        dependencias.clear();
    }
}
